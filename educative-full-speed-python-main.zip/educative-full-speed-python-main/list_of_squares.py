def getSquare():
  l1=[x*x for x in range(1,11)]
  return l1
l1=getSquare()
print(l1)