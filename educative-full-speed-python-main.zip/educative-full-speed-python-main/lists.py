#list=[element1,element2,...]

l = [1, 2, 3, 4, 5]
print(l)    #prints the entire list
print(l[0]) #prints value at index 0
print(l[1]) #prints value at index 1

z=['a','b','c','d','e']
print(z[0:3])

#for循环
x=[1,2,4,8,10]
for val in x:
  print(val)