#使用find()函数
def FindOccurence(s):
    a=s.find("b")
    b=s.find("ccc")
    return[a,b]
str="aaabbbccc"
print(FindOccurence(str))