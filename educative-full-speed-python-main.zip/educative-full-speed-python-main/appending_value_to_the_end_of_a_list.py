#使用append()函数
def AppendtoList():
  l=[1,4,9,10,23] 
  l.append(90)
  return l
l=AppendtoList()
print(l)

#方法2
x1= [1,4,9,10,23]
print(x1)
x1=x1+[90]
print(x1)