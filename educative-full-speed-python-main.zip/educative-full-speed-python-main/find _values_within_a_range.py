def inRange(x,y):
  return(x<1/3<y)
print(inRange(-1,3))
print(inRange(2,3))