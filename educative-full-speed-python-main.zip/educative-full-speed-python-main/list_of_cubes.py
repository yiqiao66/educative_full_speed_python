def getCube():
  l1=[x*x*x for x in range(1,21)]
# l1=[x**3 for x in range(1,21)]
#表示 x 的 y 次幂
  return l1
l1=getCube()
print(l1)