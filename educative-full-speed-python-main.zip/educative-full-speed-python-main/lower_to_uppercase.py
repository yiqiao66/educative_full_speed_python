#使用str.upper()和str.lower()
def changeCase(s):
    a=s.upper()
    b=s.lower()
    return[a,b]
str="AAA bbb CCC"
print(changeCase(str))