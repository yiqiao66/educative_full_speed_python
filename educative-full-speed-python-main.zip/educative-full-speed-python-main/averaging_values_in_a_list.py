#使用Python len和sum 函数
def getAverage():
  l1=[1,4,9,10,23]
  avg=sum(l1)/len(l1)  
  return avg
avg=getAverage()
print(avg)