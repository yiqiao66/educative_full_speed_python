def checkParity(n):
    result=(n%2)
    return result
print("odd parity",checkParity(17))
print("even parity",checkParity(16))